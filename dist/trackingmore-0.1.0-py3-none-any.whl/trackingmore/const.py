
ErrEmptyAPIKey = 'API Key is missing';
ErrMissingTrackingNumber      = 'Tracking number cannot be empty';
ErrMissingCourierCode         = 'Courier Code cannot be empty';
ErrMissingAwbNumber           = 'Awb number cannot be empty';
ErrMaxTrackingNumbersExceeded = 'Max. 40 tracking numbers create in one call';
ErrEmptyId                    = 'Id cannot be empty';
ErrInvalidAirWaybillFormat    = 'The air waybill number format is invalid and can only be 12 digits in length';
